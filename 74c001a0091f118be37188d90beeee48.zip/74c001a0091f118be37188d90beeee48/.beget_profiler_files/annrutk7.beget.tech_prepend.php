<?php

$allowed_ip = file("/home/a/annrutk7/.beget_profiler_files/annrutk7.beget.tech_ip");
$allowed_domains = file("/home/a/annrutk7/.beget_profiler_files/annrutk7.beget.tech_domain");

if (!in_array($_SERVER['REMOTE_ADDR'] . "\n", $allowed_ip)) {
    return;
}

$domain = $_SERVER['HTTP_HOST'] . PHP_EOL;

function isMatchingWildcard($domain, $allow_list)
{
    foreach ($allow_list as $pattern) {
        if (fnmatch($pattern, $domain)) {
            return true;
        }
    }

    return false;
}

$www_allowed_domains = array();

foreach ($allowed_domains as $allowed_domain) {
    $www_allowed_domains[] = 'www.' . $allowed_domain;
}

$in_allowed = in_array($domain, $allowed_domains);
$in_www_allowed = in_array($domain, $www_allowed_domains);
$in_wildcard_allowed = isMatchingWildcard($domain, $allowed_domains);

if (!$in_allowed && !$in_www_allowed  && !$in_wildcard_allowed) {
    return;
}

function getExtensionName()
{
    if (extension_loaded('tideways'))
    {
        return 'tideways';
    }elseif(extension_loaded('tideways_xhprof'))
    {
        return 'tideways_xhprof';
    }elseif(extension_loaded('xhprof'))
    {
        return 'xhprof';
    }

    return false;
}

$_xhprof['ext_name'] = getExtensionName();

if($_xhprof['ext_name'])
{
    $flagsCpu = constant(strtoupper($_xhprof['ext_name']).'_FLAGS_CPU');
    $flagsMemory = constant(strtoupper($_xhprof['ext_name']).'_FLAGS_MEMORY');
    $envVarName = strtoupper($_xhprof['ext_name']).'_PROFILE';
}

call_user_func($_xhprof['ext_name'].'_enable', $flagsCpu + $flagsMemory);

unset($flagsCpu);
unset($flagsMemory);

interface iXHProfRuns {
    public function save_run($xhprof_data, $run_id = null);
}

class Db_Pdo
{
    protected $curStmt;

    public $db;

    public function connect()
    {
        $connectionString =  'sqlite:/home/a/annrutk7/.beget_profiler_files/bprof_db.sqlite3';
        $db = new PDO($connectionString);
        if ($db === FALSE)
        {
            throw new Exception("Unable to connect to database");
        }

        $this->db = $db;
        $this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public function query($sql)
    {
        $this->curStmt = $this->db->query($sql);
        return $this->curStmt;
    }

    public function escape($str)
    {
        $str = $this->db->quote($str);
        $str = substr($str, 0, -1);
        $str = substr($str, 1);
        return $str;
    }

    public function affectedRows()
    {
        if ($this->curStmt === false) {
            return 0;
        }
        return $this->curStmt->rowCount();
    }
}

function _urlSimilartor($url)
{
    $url = preg_replace("!\d{4}!", "", $url);

    if($similartorinclude = getenv('xhprof_urlSimilartor_include')) {
        require_once($similartorinclude);
    }

    $url = preg_replace("![?&]_profile=\d!", "", $url);
    return $url;
}


class XHProfRuns_Default implements iXHProfRuns
{
    protected $db;

    public function __construct()
    {
        $this->db();
    }

    protected function db()
    {
        $this->db = new Db_Pdo();
        $this->db->connect();
    }

    private function gen_run_id()
    {
        return uniqid();
    }

    public static function getNextAssoc($resultSet)
    {
        return Db_Pdo::getNextAssoc($resultSet);
    }

    public function save_run($xhprof_data, $run_id = null, $xhprof_details = null)
    {
        global $_xhprof;

        $sql = array();
        if ($run_id === null) {
            $run_id = $this->gen_run_id();
        }

        $sql['get'] = $this->db->escape(json_encode($_GET));
        $sql['cookie'] = $this->db->escape(json_encode($_COOKIE));

        $sql['pmu'] = isset($xhprof_data['main()']['pmu']) ? $xhprof_data['main()']['pmu'] : 0;
        $sql['wt']  = isset($xhprof_data['main()']['wt'])  ? $xhprof_data['main()']['wt']  : 0;
        $sql['cpu'] = isset($xhprof_data['main()']['cpu']) ? $xhprof_data['main()']['cpu'] : 0;
        $sql['data'] = $this->db->escape(json_encode($xhprof_data));
        $sql['post'] = $this->db->escape(json_encode($_POST));
        $url = rawurldecode($_SERVER['REQUEST_URI']);
        $sname = isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : '';
        $sql['servername'] = $this->db->escape($sname);
        $sql['url'] = $this->db->escape($url);
        $sql['c_url'] = $this->db->escape(_urlSimilartor($url));
        $sql['type']  = (int) (isset($xhprof_details['type']) ? $xhprof_details['type'] : 0);
        $sql['timestamp'] = $this->db->escape($_SERVER['REQUEST_TIME']);
        $sql['aggregateCalls_include'] = getenv('xhprof_aggregateCalls_include') ? getenv('xhprof_aggregateCalls_include') : '';

        $query = "INSERT INTO `details` (`id`, `url`, `c_url`, `timestamp`, `server name`, `perfdata`, `type`, `cookie`, `post`, `get`, `pmu`, `wt`, `cpu`, `aggregateCalls_include`) VALUES('$run_id', '{$sql['url']}', '{$sql['c_url']}', datetime({$sql['timestamp']}, 'unixepoch'), '{$sql['servername']}', '{$sql['data']}', '{$sql['type']}', '{$sql['cookie']}', '{$sql['post']}', '{$sql['get']}', '{$sql['pmu']}', '{$sql['wt']}', '{$sql['cpu']}', '{$sql['aggregateCalls_include']}')";

        $this->db->query($query);
        if ($this->db->affectedRows() == 1)
        {
            return $run_id;
        } else
        {
            return -1;
        }
    }
}

function xhprof_shutdown_function()
{
        global $_xhprof;
        $xhprof_data = call_user_func($_xhprof['ext_name'] . '_disable');
        $xhprof_runs = new XHProfRuns_Default();
        $xhprof_runs->save_run($xhprof_data, null);
}

register_shutdown_function('xhprof_shutdown_function');